print('Starting TradNLpLus v9.3 Live Trading...')
